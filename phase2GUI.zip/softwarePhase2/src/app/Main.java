package app;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Owner;
import model.Vehicle;
import model.VehicleContainer;
import model.InsurancePolicy;
import model.AccidentContainer;
import model.AknowledgementContainer;
import model.InsuranceCompany;

/**
 * @author Dima
 * @author Aisha
 * The main entry point for the Car System application.
 * <p>
 * This application provides functionalities for managing vehicles, owners, insurance policies, 
 * accidents, and acknowledgements. The {@link Main} class initializes the JavaFX application, 
 * preloads sample data, and sets up the primary stage with the main menu interface.
 * </p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li>Preloads sample data for demonstration purposes.</li>
 *   <li>Loads the main menu interface using JavaFX FXML.</li>
 *   <li>Provides utility methods to check accident and acknowledgement containers.</li>
 * </ul>

 */
public class Main extends Application {

    /**
     * Starts the JavaFX application and initializes the primary stage.
     * <p>
     * This method preloads sample data and sets up the main menu interface using an FXML loader.
     * </p>
     * 
     * @param primaryStage The primary stage for the application.
     */
    @Override
    public void start(Stage primaryStage) {
        try {
            preloadData();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainMenu.fxml"));
            Scene scene = new Scene(loader.load());
            primaryStage.setTitle("Car System");
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Preloads sample data into the application.
     * <p>
     * This method creates sample {@link Vehicle}, {@link Owner}, and {@link InsurancePolicy} objects
     * and adds them to the {@link VehicleContainer}. It is intended for demonstration and testing purposes.
     * </p>
     */
    private void preloadData() {
        Owner offenderOwner = new Owner("Dima Faris", 123, "dima.faris@example.com", 123456789);
        Owner victimOwner = new Owner("Sara Khalid", 456, "sara.khalid@example.com", 987654321);

        InsurancePolicy offenderPolicy = new InsurancePolicy(101, true, new InsuranceCompany("Company A", false));
        InsurancePolicy victimPolicy = new InsurancePolicy(102, true, new InsuranceCompany("Company B", false));

        Vehicle offenderVehicle = new Vehicle(
            101,                 // VIN
            2020,                // Year Manufactured
            "Toyota",            // Make
            offenderOwner,       // Owner
            offenderPolicy,      // Insurance Policy
            "Camry"              // Model
        );

        Vehicle victimVehicle = new Vehicle(
            102,                 // VIN
            2018,                // Year Manufactured
            "Honda",             // Make
            victimOwner,         // Owner
            victimPolicy,        // Insurance Policy
            "Civic"              // Model
        );

        VehicleContainer.addVehicle(offenderVehicle);
        VehicleContainer.addVehicle(victimVehicle);
    }

    /**
     * Checks and prints the accident reports stored in the {@link AccidentContainer}.
     * <p>
     * If no accident reports are present, a message is printed indicating an empty container.
     * Otherwise, all accident reports are listed.
     * </p>
     */
    private static void checkAccidentReportContainer() {
        if (AccidentContainer.getReports().isEmpty()) {
            System.out.println("No accident reports in the container.");
        } else {
            System.out.println("Accident Reports in container:");
            AccidentContainer.getReports().forEach(report -> {
                System.out.println(report);
            });
        }
    }

    /**
     * Checks and prints the acknowledgements stored in the {@link AknowledgementContainer}.
     * <p>
     * If no acknowledgements are present, a message is printed indicating an empty container.
     * Otherwise, all acknowledgements are listed.
     * </p>
     */
    private static void checkAcknowledgementContainer() {
        if (AknowledgementContainer.getAknowledgements().isEmpty()) {
            System.out.println("No acknowledgements in the container.");
        } else {
            System.out.println("Acknowledgements in container:");
            AknowledgementContainer.getAknowledgements().forEach(ack -> {
                System.out.println(ack);
            });
        }
    }

    /**
     * The main entry point for the application.
     * <p>
     * This method launches the JavaFX application and initializes the UI.
     * </p>
     * 
     * @param args Command-line arguments (not used in this application).
     */
    public static void main(String[] args) {
        launch(args);
    }
}
