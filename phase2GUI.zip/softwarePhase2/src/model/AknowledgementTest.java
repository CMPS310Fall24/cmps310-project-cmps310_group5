package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * 
 * @author dima
 * 
 * Unit test class for the {@link Aknowledgement} class.
 * This class uses JUnit 5 to validate the functionality of the {@link Aknowledgement} class,
 * ensuring proper behavior of its methods and attributes.
 * 
 * The tests cover:
 * <ul>
 *   <li>Validation of the report content</li>
 *   <li>Insurance company linkage</li>
 *   <li>Acknowledgement status</li>
 * </ul>
 * 
 */
class AknowledgementTest {

    // Sample data for testing
    InsuranceCompany insurancecompany = new InsuranceCompany("Company A", false);
    Aknowledgement acknowledgement = new Aknowledgement("mock report", insurancecompany, true);

    /**
     * Tests the {@link Aknowledgement#getReport()} method.
     * Ensures the report content is correctly retrieved.
     */
    @Test
    void testGetReport() {
        assertEquals("mock report", acknowledgement.getReport());
    }

    /**
     * Comprehensive test to validate all aspects of an {@link Aknowledgement}.
     * Calls individual test methods for each attribute and behavior.
     */
    @Test
    void testAknowledgement() {
        testGetReport();
        testGetCompany();
        testGetAknowledgement();
    }

    /**
     * Tests the {@link Aknowledgement#getCompany()} method.
     * Ensures the associated insurance company is correctly retrieved.
     */
    @Test
    void testGetCompany() {
        assertEquals(insurancecompany, acknowledgement.getCompany());
    }

    /**
     * Tests the {@link Aknowledgement#getAknowledgement()} method.
     * Ensures the acknowledgement status is correctly retrieved.
     */
    @Test
    void testGetAknowledgement() {
        assertEquals(true, acknowledgement.getAknowledgement());
    }
}
