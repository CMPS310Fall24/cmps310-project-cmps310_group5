package model;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author dima
 * The {@code AccidentContainer} class is responsible for managing a collection of {@code Accident} objects.
 * it allows adding,retrieving and finding accidents 
 * the reports are stored in a static list that can be accessed and modified using static and instance methods
 */
public class AccidentContainer {
	/**
	 * a static list to hold the accidents
	 * 

	 */
    private static final List<Accident> accidents = new ArrayList<>();
/**
 * 
 * adds an {@code Accident} instance to the container
 *  @param report The {@code Accident} report to be added.

 */
    public static void addReport(Accident report) {
        accidents.add(report);
    }
/**
 * 
 * @return returns the list containing all  accidents 
 */
    public static List<Accident> getReports() {
        return new ArrayList<>(accidents);
    }
    /**
     * Finds an {@code Accident} report by its case number 
     * @param caseNo the case number of the accident to be found
     * @return the {@code Accident} with the correct case number and {@code null} if no accident was found
     */
    public Accident findAccident(int caseNo) {
    	for(Accident accident: accidents) {
    		if(accident.getCaseNumber()==caseNo) {
    			return accident;
    		}
    	}
    	 System.err.println("Error: No Accident found with this VIN.");
	        return null;
    }
    /**
     * 
     * @param caseNo the case number of the accident 
     * removes the {@code Accident) with the correct case number 
     */
    public static void removeReport(int caseNo) {
        boolean found = false;
        for (int i = 0; i < accidents.size(); i++) { 
            if (accidents.get(i).getCaseNumber() == caseNo) { 
                accidents.remove(i);
                found = true;
                break; 
            }
        }
        if (!found) {
            System.out.println("No accident with this caseNo");
        }
    }
}