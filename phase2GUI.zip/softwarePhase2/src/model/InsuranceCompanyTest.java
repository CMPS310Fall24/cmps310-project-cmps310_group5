package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author dima
 * 
 * Unit test class for the {@link InsuranceCompany} class.
 * This class uses JUnit 5 to validate the functionality of the {@link InsuranceCompany} class,
 * ensuring proper behavior of its methods and attributes.
 * 
 * The tests cover:
 * <ul>
 *   <li>Retrieving the company name</li>
 *   <li>Validating the approval process</li>
 * </ul>
 * 
 */
class InsuranceCompanyTest {

    // Sample data for testing
    InsuranceCompany insurancecompany = new InsuranceCompany("Company A", false);

    /**
     * Comprehensive test to validate all aspects of an {@link InsuranceCompany}.
     * Calls individual test methods for each attribute and behavior.
     */
    @Test
    void testInsuranceCompany() {
        testGetCompanyName();
        testGiveApproval();
    }

    /**
     * Tests the {@link InsuranceCompany#getCompanyName()} method.
     * Ensures the company name is correctly retrieved.
     */
    @Test
    void testGetCompanyName() {
        assertEquals("Company A", insurancecompany.getCompanyName());
    }

    /**
     * Tests the {@link InsuranceCompany#giveApproval(Object)} method.
     * Ensures the approval process returns the expected result.
     * In this case, the test validates that approval is always given.
     */
    @Test
    void testGiveApproval() {
        assertEquals(true, insurancecompany.giveApproval(null));
    }
}
