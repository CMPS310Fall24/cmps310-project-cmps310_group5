package model;

/**
 * Represents an insurance policy associated with an {@link InsuranceCompany}.
 * This class contains information about the policy number, its validity, and the associated insurance company.
 * It provides methods to get and set policy details, such as the policy number and validity status.
 
 * 
 * @author dima
 */
public class InsurancePolicy {

    // Policy number
    private int policyNo;
    
    // Validity status of the policy
    private boolean validity;
    
    // Insurance company that issued the policy
    private InsuranceCompany company;

    /**
     * Constructs an {@link InsurancePolicy} with the specified policy number, validity status, and insurance company.
     * 
     * @param policyNo The policy number.
     * @param validity The validity status of the policy (true if valid, false otherwise).
     * @param company The insurance company that issued the policy.
     */
    public InsurancePolicy(int policyNo, boolean validity, InsuranceCompany company) {
        super();
        this.policyNo = policyNo;
        this.validity = validity;
        this.company = company;
    }

    /**
     * Retrieves the insurance company associated with this policy.
     * @return The {@link InsuranceCompany} associated with this policy.
     */
    public InsuranceCompany getCompany() {
        return company;
    }

    /**
     * Sets the insurance company for this policy.
     * @param company The insurance company to set.
     */
    public void setCompany(InsuranceCompany company) {
        this.company = company;
    }

    /**
     * Retrieves the policy number of this insurance policy.
     * 
     * @return The policy number.
     */
    public int getPolicyNo() {
        return policyNo;
    }

    /**
     * Sets the policy number for this insurance policy.
     * @param policyNo The policy number to set.
     */
    public void setPolicyNo(int policyNo) {
        this.policyNo = policyNo;
    }

    /**
     * Retrieves the validity status of the insurance policy.
     * 
     * @return {@code true} if the policy is valid, {@code false} otherwise.
     */
    public boolean isValidity() {
        return validity;
    }

    /**
     * Sets the validity status of the insurance policy.
     * @param validity The validity status to set.
     */
    public void setValidity(boolean validity) {
        this.validity = validity;
    }

    /**
     * Returns a string representation of the {@link InsurancePolicy} object, including the policy number, validity, and associated company.
     * @return A string representation of the policy details.
     */
    @Override
    public String toString() {
        return "InsurancePolicy [policyNo=" + policyNo + ", validity=" + validity + ", company=" + company + "]";
    }
}