package model;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalTime;

import org.junit.jupiter.api.Test;

/**
 * @author dima
 * 
 * Unit test class for the {@link Accident} class.
 * This class uses JUnit 5 to validate the functionality of the {@link Accident} class,
 * ensuring correct behavior of its methods and attributes.
 * 
 * The tests cover:
 * <ul>
 *   <li>Accident attributes, such as date, time, location, victim, and offender</li>
 *   <li>Accident-specific behavior, including report generation</li>
 * </ul>
 * 
 *
 */
class AccidentTest {

    // Sample data for testing
    Owner Offender = new Owner("Dima Faris", 123, "dima.faris@example.com", 123456789);
    Owner Victim = new Owner("Sara Khalid", 456, "sara.khalid@example.com", 987654321);
    InsurancePolicy offenderPolicy = new InsurancePolicy(101, true, new InsuranceCompany("Company A", false));
    InsurancePolicy victimPolicy = new InsurancePolicy(102, true, new InsuranceCompany("Company B", false));
    Accident accident = new Accident(
            LocalDate.of(2024, 11, 23),  // Date of the accident
            LocalTime.of(14, 30),        // Time of the accident
            "Downtown",                  // Location of the accident
            Victim,                      // Victim in the accident
            Offender                     // Offender in the accident
    );
    Vehicle offenderVehicle = new Vehicle(
            101,                // VIN
            2020,               // Year Manufactured
            "Toyota",           // Make
            Offender,           // Owner
            offenderPolicy,     // Insurance Policy
            "Camry"             // Model
    );

    Vehicle victimVehicle = new Vehicle(
            102,                // VIN
            2018,               // Year Manufactured
            "Honda",            // Make
            Victim,             // Owner
            victimPolicy,       // Insurance Policy
            "Civic"             // Model
    );

    /**
     * Comprehensive test to validate all aspects of an {@link Accident}.
     * Calls individual test methods for each attribute and behavior.
     */
    @Test
    void testAccident() {
        testGetDate();
        testGetTime();
        testGetLocation();
        testGetVictim();
        testGetOffender();
        testGetCaseNumber();
        testGetReport();
        testGenerateReport();
    }

    /**
     * Tests the {@link Accident#getDate()} method.
     * Ensures the date of the accident is correctly retrieved.
     */
    @Test
    void testGetDate() {
        assertEquals(LocalDate.of(2024, 11, 23), accident.getDate());
    }

    /**
     * Tests the {@link Accident#getTime()} method.
     * Ensures the time of the accident is correctly retrieved.
     */
    @Test
    void testGetTime() {
        assertEquals(LocalTime.of(14, 30), accident.getTime());
    }

    /**
     * Tests the {@link Accident#getLocation()} method.
     * Ensures the location of the accident is correctly retrieved.
     */
    @Test
    void testGetLocation() {
        assertEquals("Downtown", accident.getLocation());
    }

    /**
     * Tests the {@link Accident#getVictim()} method.
     * Ensures the victim details are correctly retrieved.
     */
    @Test
    void testGetVictim() {
        assertEquals(Victim, accident.getVictim());
    }

    /**
     * Tests the {@link Accident#getOffender()} method.
     * Ensures the offender details are correctly retrieved.
     */
    @Test
    void testGetOffender() {
        assertEquals(Offender, accident.getOffender());
    }

    /**
     * Tests the {@link Accident#getCaseNumber()} method.
     * Ensures the case number is correctly retrieved.
     * Assumes the default case number is 1.
     */
    @Test
    void testGetCaseNumber() {
        assertEquals(1, accident.getCaseNumber());
    }

    /**
     * Tests the {@link Accident#getReport()} method.
     * Ensures the report is initially null before generation.
     */
    @Test
    void testGetReport() {
        assertNull(accident.getReport());
    }

    /**
     * Tests the {@link Accident#generateReport()} method.
     * Validates that the generated report matches the expected format.
     */
    @Test
    void testGenerateReport() {
        accident.generateReport();

        String expectedReport = """
                Accident Report:
                =====================
                Case Number: 1
                Date: 2024-11-23
                Time: 14:30
                Location: Downtown
                Victim: Owner [name=Jane Smith, QID=456, address=jane.smith@example.com, phoneNumber=987654321]
                Offender: Owner [name=John Doe, QID=123, address=john.doe@example.com, phoneNumber=123456789]
                =====================
                """;

        assertEquals(expectedReport, accident.getReport());
    }
}
