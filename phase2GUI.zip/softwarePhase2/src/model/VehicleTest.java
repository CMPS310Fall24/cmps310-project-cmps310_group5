package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Dima
 *  
 * Unit test class for the {@link Vehicle} class.
 * This class uses JUnit 5 to validate the functionality of the {@link Vehicle} class,
 * ensuring that its attributes and methods work as expected.
 * 
 * <p>The tests cover:</p>
 * <ul>
 *   <li>Retrieving the vehicle's VIN</li>
 *   <li>Retrieving the associated insurance policy</li>
 *   <li>Retrieving the year of manufacture</li>
 *   <li>Retrieving the make and model of the vehicle</li>
 *   <li>Retrieving the owner's details</li>
 * </ul>
 * 
 */
class VehicleTest {

    // Sample data for testing
    Owner owner = new Owner("Sara Khalid", 456, "sara.khalid@example.com", 987654321);
    InsurancePolicy policy = new InsurancePolicy(101, true, new InsuranceCompany("Company A", false));
    Vehicle vehicle = new Vehicle(
            101,                 // VIN
            2020,                // Year Manufactured
            "Toyota",            // Make
            owner,               // Owner
            policy,              // Insurance Policy
            "Camry"              // Model
    );

    /**
     * Tests the {@link Vehicle#getVIN()} method.
     * Ensures the Vehicle Identification Number (VIN) is correctly retrieved.
     */
    @Test
    void testGetVIN() {
        assertEquals(101, vehicle.getVIN());
    }

    /**
     * Tests the {@link Vehicle#getPolicy()} method.
     * Ensures the insurance policy associated with the vehicle is correctly retrieved.
     */
    @Test
    void testGetPolicy() {
        assertEquals(policy, vehicle.getPolicy());
    }

    /**
     * Tests the {@link Vehicle#getYearM()} method.
     * Ensures the year of manufacture is correctly retrieved.
     */
    @Test
    void testGetYearM() {
        assertEquals(2020, vehicle.getYearM());
    }

    /**
     * Tests the {@link Vehicle#getMake()} method.
     * Ensures the make (manufacturer) of the vehicle is correctly retrieved.
     */
    @Test
    void testGetMake() {
        assertEquals("Toyota", vehicle.getMake());
    }

    /**
     * Tests the {@link Vehicle#getModel()} method.
     * Ensures the model of the vehicle is correctly retrieved.
     */
    @Test
    void testGetModel() {
        assertEquals("Camry", vehicle.getModel());
    }

    /**
     * Tests the {@link Vehicle#getOwner()} method.
     * Ensures the owner of the vehicle is correctly retrieved.
     */
    @Test
    void testGetOwner() {
        assertEquals(owner, vehicle.getOwner());
    }

    /**
     * Comprehensive test to validate all aspects of a {@link Vehicle}.
     * Calls individual test methods for each attribute and behavior.
     */
    @Test
    void testVehicle() {
        testGetVIN();
        testGetPolicy();
        testGetYearM();
        testGetMake();
        testGetModel();
        testGetOwner();
    }
}

