package model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;
/**
 * 
 * @author dima
 * represents the accident class, includes details about the date,time,location
 * includes the victim,offender and the confirmation of the accident
 * includes a String report
 * 
 */
public class Accident{
	LocalDate date;
	LocalTime time;
	String Location;
	Owner victim;
	Owner Offender;
	int caseNumber;
	String report;
	boolean confirmation;

	
	

	

/**
   * Constructs an {@code Accident} instance with the specified details.

 * constructs on 
 * @param date date of the accident
 * @param time time of the accident
 * @param location location of the accident
 * @param victim victim of the accident
 * @param offender offender of the accident
 */
public Accident(LocalDate date, LocalTime time, String location, Owner victim,
			Owner offender) {
		super();
		this.date = date;
		this.time = time;
		Location = location;
		this.victim = victim;
		Offender = offender;
		this.caseNumber = caseNumber+1;
		this.report=null;
		this.confirmation=false;
	}






/**
 * 
 * @return returns the confirmation from the offender of the accident details
 */

public boolean isConfirmation() {
	return confirmation;
}







/**
 * 
 * @param confirmation sets the offender involved in the accident
 */
public void setConfirmation(boolean confirmation) {
	this.confirmation = confirmation;
}






/**
 * 
 * @return returns the date of the accident 
 */

public LocalDate getDate() {
		return date;
	}


/**
 * 
 * @param sets the date of the accident
 */
	public void setDate(LocalDate date) {
		this.date = date;
	}


/**
 * 
 * @return returns the time of the accident
 */
	public LocalTime getTime() {
		return time;
	}


/**
 * 
 * @param sets the time of the accident
 */
	public void setTime(LocalTime time) {
		this.time = time;
	}





/**
 * 
 * @returns the location of the accident
 */

	public String getLocation() {
		return Location;
	}


/**
 * 
 * @param set the location of the accident
 */
	public void setLocation(String location) {
		Location = location;
	}


/**
 * 
 * @return the owner who is the victim of the accident
 */
	public Owner getVictim() {
		return victim;
	}


/**
 * 
 * @param sets the victim of the accident
 */
	public void setVictim(Owner victim) {
		this.victim = victim;
	}


/**
 * 
 * @return returns the owner who is the offender of the accident
 */
	public Owner getOffender() {
		return Offender;
	}


/**
 * 
 * @param sets the offender of the accident
 */
	public void setOffender(Owner offender) {
		Offender = offender;
	}


/**
 * 
 * @return returns the case number of the accident
 */
	public int getCaseNumber() {
		return caseNumber;
	}


/**
 * 
 * @param sets the caseNumber of the accident
 */
	public void setCaseNumber(int caseNumber) {
		this.caseNumber = caseNumber;
	}

/**
 * 
 * @retur returns the report of the accident
 */
   public String getReport() {
	   return report;
   }
/**
 * a to string method for the report
 */
	@Override
	public String toString() {
		return "AccidentReport [date=" + date + ", time=" + time + ", Location=" + Location + ", victim=" + victim
				+ ", Offender=" + Offender + ", caseNumber=" + caseNumber;
	}
	/**
	 * A method that generates a string report to describe the whole accident
	 */
	 public void generateReport() {
	        report="Accident Report:\n" +
	               "=====================\n" +
	               "Case Number: " + caseNumber + "\n" +
	               "Date: " + date + "\n" +
	               "Time: " + time + "\n" +
	               "Location: " + Location + "\n" +
	               "Victim: " + victim +
	               "Offender: " + Offender+
	               "confirmed:"+ confirmation+
	               "=====================";
	    }

}


