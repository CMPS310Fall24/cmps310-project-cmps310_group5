package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author dima
 * 
 * Unit test class for the {@link InsurancePolicy} class.
 * This class uses JUnit 5 to validate the functionality of the {@link InsurancePolicy} class,
 * ensuring correct behavior of its methods and attributes.
 * 
 * The tests cover:
 * <ul>
 *   <li>Retrieving the associated insurance company</li>
 *   <li>Retrieving the policy number</li>
 *   <li>Checking the validity status of the policy</li>
 * </ul>
 * 
 */
class InsurancePolicyTest {

    // Sample data for testing
    InsuranceCompany insurancecompany = new InsuranceCompany("Company A", false);
    InsurancePolicy policy = new InsurancePolicy(101, true, insurancecompany);

    /**
     * Tests the {@link InsurancePolicy#getCompany()} method.
     * Ensures the associated insurance company is correctly retrieved.
     */
    @Test
    void testGetCompany() {
        assertEquals(insurancecompany, policy.getCompany());
    }

    /**
     * Comprehensive test to validate all aspects of an {@link InsurancePolicy}.
     * Calls individual test methods for each attribute and behavior.
     */
    @Test
    void testInsurancePolicy() {
        testGetCompany();
        testGetPolicyNo();
        testIsValidity();
    }

    /**
     * Tests the {@link InsurancePolicy#getPolicyNo()} method.
     * Ensures the policy number is correctly retrieved.
     */
    @Test
    void testGetPolicyNo() {
        assertEquals(101, policy.getPolicyNo());
    }

    /**
     * Tests the {@link InsurancePolicy#isValidity()} method.
     * Ensures the validity status of the policy is correctly retrieved.
     */
    @Test
    void testIsValidity() {
        assertEquals(true, policy.isValidity());
    }
}
