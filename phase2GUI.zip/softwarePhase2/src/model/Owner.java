package model;

/**
 * @author Dima
 * @author Aisha
 * 
 * Represents the owner of a vehicle.
 * <p>
 * This class contains information about the owner, including their name, Qatar ID (QID), address, and phone number.
 * It provides methods to get and set owner details and a {@link #toString()} method for returning a string representation of the owner.
 * </p>
 * 
 * 
 */
public class Owner {
    
    // Owner's name
    private String name;
    
    // Owner's Qatar ID (QID)
    private int QID;
    
    // Owner's address
    private String address;
    
    // Owner's phone number
    private int phoneNumber;

    /**
     * Constructs an {@link Owner} with the specified details.
     * 
     * @param name The name of the owner.
     * @param QID The Qatar ID of the owner.
     * @param address The address of the owner.
     * @param phoneNumber The phone number of the owner.
     */
    
    public Owner(int QID, String name) {
        this.QID = QID;
        this.name = name;
    }

    
    public Owner(String name, int QID, String address, int phoneNumber) {
        super();
        this.name = name;
        this.QID = QID;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    /**
     * Retrieves the name of the owner.
     * 
     * @return The name of the owner.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the owner.
     * 
     * @param name The name of the owner to set.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Retrieves the Qatar ID (QID) of the owner.
     * 
     * @return The Qatar ID of the owner.
     */
    public int getQID() {
        return QID;
    }

    /**
     * Sets the Qatar ID (QID) of the owner.
     * 
     * @param QID The Qatar ID of the owner to set.
     */
    public void setQID(int QID) {
        this.QID = QID;
    }

    /**
     * Retrieves the address of the owner.
     * 
     * @return The address of the owner.
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the address of the owner.
     * 
     * @param address The address of the owner to set.
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Retrieves the phone number of the owner.
     * 
     * @return The phone number of the owner.
     */
    public int getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the phone number of the owner.
     * 
     * @param phoneNumber The phone number of the owner to set.
     */
    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * Returns a string representation of the {@link Owner} object, including the owner's name, Qatar ID, address, and phone number.
     * 
     * @return A string representation of the owner details.
     */
    @Override
    public String toString() {
        return "Owner [name=" + name + ", QID=" + QID + ", address=" + address + ", phoneNumber=" + phoneNumber + "]";
    }
}
