package model;

/**
 * Represents an insurance company that can approve or reject reports.
 * This class contains information about the company name and its approval status.
 * It provides methods to set approval, get company details, and give approval on reports.
 * 
 * @author dima
 */
public class InsuranceCompany {

    private String companyName;
    
    private boolean approval;

    /**
     * Constructs an {@link InsuranceCompany} with the specified company name and initial approval status.
     * 
     * @param companyName The name of the insurance company.
     * @param approval The approval status of the company (initially set to {@code false}).
     */
    public InsuranceCompany(String companyName, boolean approval) {
        super();
        this.companyName = companyName;
        this.approval = false; // Default approval status set to false
    }

    /**
     * Retrieves the approval status of the insurance company.
     * 
     * @return {@code true} if the company has approved, {@code false} otherwise.
     */
    public boolean isApproval() {
        return approval;
    }

    /**
     * Sets the approval status of the insurance company.
     * @param approval The approval status to set.
     */
    public void setApproval(boolean approval) {
        this.approval = approval;
    }

    /**
     * Retrieves the name of the insurance company.
     * @return The name of the company.
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * Sets the name of the insurance company.
     * @param companyName The name of the company to set.
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    /**
     * Gives approval to a report, setting the company's approval status to {@code true}.
     * 
     * @param report The report that is being approved (the report is not used in this method).
     * @return {@code true} indicating the company has approved the report.
     */
    public boolean giveApproval(String report) {
        setApproval(true); // Set approval status to true
        return true;
    }

    /**
     * returns a string representation of the {@link InsuranceCompany} object, including the company name and approval status.
     * 
     * @return A string representation of the company name and approval status.
     */
    @Override
    public String toString() {
        return "InsuranceCompany [companyName=" + companyName + ", approval=" + approval + "]";
    }
}
