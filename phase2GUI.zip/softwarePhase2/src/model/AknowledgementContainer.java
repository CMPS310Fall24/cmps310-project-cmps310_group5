package model;

import java.util.ArrayList;
import java.util.List;

/**
 * A container class that holds a list of {@link Aknowledgement} instances.
 * It provides methods to add and retrieve {@link Aknowledgement} reports.
 * This class uses a static list to store the acknowledgements, ensuring that all instances
 * of the class share the same list.
 * 
 * 
 * @author dima
 */
public class AknowledgementContainer {

    // Static list to store Aknowledgement objects
    private static final List<Aknowledgement> aknowledgements = new ArrayList<>();

    /**
     * Adds an {@link Aknowledgement} report to the container.
     * @param aknowledgement The {@link Aknowledgement} report to be added to the list.
     */
    public static void addReport(Aknowledgement aknowledgement) {
        aknowledgements.add(aknowledgement);
    }

    /**
     * Retrieves a copy of the list of all {@link Aknowledgement} reports in the container.
     * @return A list containing all {@link Aknowledgement} objects.
     */
    public static List<Aknowledgement> getAknowledgements() {
        return new ArrayList<>(aknowledgements);
    }
    /**
     * 
     * @param report belonging to the accident 
     * removes the aknowledgement from the list with the report 
     */
    public static void removeAknowledgement(String report) {
        boolean found = false;

    	for(int i=0;i<aknowledgements.size();i++) {
    		if(aknowledgements.get(i).getReport().equals(report)) {
    			aknowledgements.remove(i);
    			found=true;
    			break;
    		}
    	}
    	 if (!found) {
             System.out.println("No Acknowledgement for this report");
         }
    } 
    /**
     * 
     * @param report belonging to accident 
     * @return returns the aknowledgement belonging to the accident report 
     */
    public static Aknowledgement findAknowledgement(String report) {
    	for(Aknowledgement aknowledgement: aknowledgements) {
    		if(aknowledgement.getReport().equals(report)) {
    			return aknowledgement;
    		}
 
    	}
    	return null;
    }
}