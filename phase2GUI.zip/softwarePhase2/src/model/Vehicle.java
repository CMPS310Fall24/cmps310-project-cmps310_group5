package model;

/**
 * @author Dima
 * @author Aisha
 * 
 * Represents a vehicle with associated details such as VIN, year of manufacture, make, model, owner, 
 * current owner, previous owner, unpaid bills status, and an insurance policy.
 * <p>
 * This class provides methods to access and modify various attributes of the vehicle, such as its 
 * identification number, owner details, and insurance policy. It also offers functionality to 
 * track ownership changes and unpaid bill status.
 * </p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li>Manage vehicle details like VIN, make, model, and year of manufacture.</li>
 *   <li>Support for tracking current and previous owners.</li>
 *   <li>Integration with insurance policy details.</li>
 *   <li>Support for unpaid bill status.</li>
 * </ul>
 * 
 */
public class Vehicle {

    private int VIN; // Vehicle Identification Number
    private int yearM; // Year of Manufacture
    private String make; // Manufacturer (e.g., Toyota, BMW)
    private Owner owner; // The owner of the vehicle
    //private Owner currentOwner; // The current owner of the vehicle
    private Owner previousOwner; // The previous owner of the vehicle
    private boolean hasUnpaidBills; // Indicates if the vehicle has unpaid bills
    private InsurancePolicy policy; // The insurance policy associated with the vehicle
    private String model; // Model of the vehicle (e.g., Corolla, X5)

    /**
     * Constructs a new {@link Vehicle} with the specified details.
     * 
     * @param vIN The Vehicle Identification Number.
     * @param yearM The year of manufacture of the vehicle.
     * @param make The make of the vehicle.
     * @param owner The owner of the vehicle.
     * @param policy The insurance policy associated with the vehicle.
     * @param model The model of the vehicle.
     */
    public Vehicle(int vIN, int yearM, String make, Owner owner, InsurancePolicy policy, String model) {
        super();
        this.VIN = vIN;
        this.yearM = yearM;
        this.make = make;
        this.owner = owner;
        this.policy = policy;
        this.model = model;
    }

    /**
     * Constructs a new {@link Vehicle} with basic details such as VIN, current owner, and unpaid bills status.
     * 
     * @param vin The Vehicle Identification Number.
     * @param currentOwner The current owner of the vehicle.
     * @param hasUnpaidBills Whether the vehicle has unpaid bills.
     */
    public Vehicle(int vin, Owner owner, boolean hasUnpaidBills) {
        this.VIN = vin;
        this.owner = owner;
        //this.currentOwner = currentOwner;
        this.hasUnpaidBills = hasUnpaidBills;
    }

    /**
     * Retrieves the Vehicle Identification Number (VIN) of the vehicle.
     * 
     * @return The VIN of the vehicle.
     */
    public int getVIN() {
        return VIN;
    }

    /**
     * Sets the Vehicle Identification Number (VIN) of the vehicle.
     * 
     * @param vIN The VIN to set.
     */
    public void setVIN(int vIN) {
        this.VIN = vIN;
    }

    /**
     * Retrieves the insurance policy associated with the vehicle.
     * 
     * @return The insurance policy of the vehicle.
     */
    public InsurancePolicy getPolicy() {
        return policy;
    }

    /**
     * Sets the insurance policy for the vehicle.
     * 
     * @param policy The insurance policy to set.
     */
    public void setPolicy(InsurancePolicy policy) {
        this.policy = policy;
    }

    /**
     * Retrieves the year of manufacture of the vehicle.
     * 
     * @return The year of manufacture.
     */
    public int getYearM() {
        return yearM;
    }

    /**
     * Sets the year of manufacture for the vehicle.
     * 
     * @param yearM The year of manufacture to set.
     */
    public void setYearM(int yearM) {
        this.yearM = yearM;
    }

    /**
     * Retrieves the make of the vehicle (e.g., Toyota, BMW).
     * 
     * @return The make of the vehicle.
     */
    public String getMake() {
        return make;
    }

    /**
     * Sets the make of the vehicle.
     * 
     * @param make The make of the vehicle to set.
     */
    public void setMake(String make) {
        this.make = make;
    }

    /**
     * Retrieves the model of the vehicle (e.g., Corolla, X5).
     * 
     * @return The model of the vehicle.
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the model of the vehicle.
     * 
     * @param model The model of the vehicle to set.
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * Retrieves the owner of the vehicle.
     * 
     * @return The owner of the vehicle.
     */
    public Owner getOwner() {
        return owner;
    }

    /**
     * Sets the owner of the vehicle, ensuring the new owner is different from the current one.
     * 
     * @param owner The new owner of the vehicle to set.
     */
    public void setOwner(Owner owner) {
        if (this.owner != owner) { // Prevent redundant operations
            this.owner = owner;
        }
    }

    /**
     * Retrieves the current owner of the vehicle.
     * 
     * @return The current owner of the vehicle.
     */
//    public Owner getCurrentOwner() {
//        return currentOwner;
//    }

    /**
     * Sets the current owner of the vehicle.
     * 
     * @param currentOwner The new current owner of the vehicle.
     */
//    public void setCurrentOwner(Owner currentOwner) {
//        this.currentOwner = currentOwner;
//    }

    /**
     * Retrieves the previous owner of the vehicle.
     * 
     * @return The previous owner of the vehicle.
     */
    public Owner getPreviousOwner() {
        return previousOwner;
    }

    /**
     * Sets the previous owner of the vehicle.
     * 
     * @param previousOwner The previous owner to set.
     */
    public void setPreviousOwner(Owner previousOwner) {
        this.previousOwner = previousOwner;
    }

    /**
     * Checks if the vehicle has unpaid bills.
     * 
     * @return True if the vehicle has unpaid bills, false otherwise.
     */
    public boolean hasUnpaidBills() {
        return hasUnpaidBills;
    }

    /**
     * Returns a string representation of the {@link Vehicle} object, including the vehicle's VIN, year, make, model,
     * owner details, and associated insurance policy.
     * 
     * @return A string representation of the vehicle details.
     */
    @Override
    public String toString() {
        return "Vehicle [VIN=" + VIN + ", yearM=" + yearM + ", make=" + make + ", owner=" + owner + ", policy=" + policy
                + ", model=" + model + "]";
    }
}
