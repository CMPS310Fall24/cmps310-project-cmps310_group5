package model;

/**
 * 
 * @author dima
 * represents the acknowledgement given by the insurance policy and includes the accident report, insurance company and a boolean representation of the acknowledgement
 * 
 */
public class Aknowledgement {
String report;
InsuranceCompany company;
boolean aknowledgement;
/**
 * 
 * @return returns the string accident report
 */
public String getReport() {
	return report;
}
/**
 * 
 * @param the accident report
 * sets the accident report 
 */
public void setReport(String report) {
	this.report = report;
}
/**
 * 
 * @param  the accident report
 * @param the insurance company 
 * @param the representation of the acknowledgement from the insurance company
 * constructs an instance of {@code Aknowledgement} using the parameters above 
 * 
 */
public Aknowledgement(String report, InsuranceCompany company, boolean aknowledgement) {
	super();
	this.report = report;
	this.company = company;
	this.aknowledgement = aknowledgement;
}

/**
 * 
 * @return returns the insurance company assigning the acknowledement 
 * 
 */
public InsuranceCompany getCompany() {
	return company;
}
/**
 * 
 * @param insurance company assigning the acknowledgement 
 * sets the insurance company 
 */
public void setCompany(InsuranceCompany company) {
	this.company = company;
}
/**
 * 
 * @return returns the boolean representation of the acknowledgement 
 */
public boolean getAknowledgement() {
	return aknowledgement;
}
/**
 * 
 * @param aknowledgement boolean acknowledgement 
 * sets the acknowledgement
 * 
 */
public void setAknowledgement(boolean aknowledgement) {
	this.aknowledgement = aknowledgement;
}
/**
 * 
 * @param  the accident report
 * @param the insurance company 
 * @param the representation of the acknowledgement from the insurance company
 * method to generate 
 */
public static void generateAknowledgement(String report, InsuranceCompany company,boolean aknowledgement) {
	Aknowledgement approvalInsurance=new Aknowledgement(report,company,aknowledgement);
	AknowledgementContainer.addReport(approvalInsurance);
}
/**
 * string method to display the acknowledgement
 */
@Override
public String toString() {
	return "Aknowledgement [report=" + report + ", company=" + company + ", aknowledgement=" + aknowledgement + "]";
}

}
