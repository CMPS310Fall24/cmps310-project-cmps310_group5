package model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Dima
 * A container class for managing a collection of {@link Vehicle} objects.
 * <p>
 * This class provides static methods to add, retrieve, check, and remove vehicles based on their VIN. 
 * It ensures that VINs are unique within the container and offers utility methods for vehicle management.
 * </p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li>Add a new vehicle to the container.</li>
 *   <li>Retrieve a vehicle by its VIN.</li>
 *   <li>Check if a VIN already exists in the container.</li>
 *   <li>Remove a vehicle from the container using its VIN.</li>
 * </ul>
 * 
 */
public class VehicleContainer {

    private static List<Vehicle> vehicles = new ArrayList<>(); // Static list of vehicles

    /**
     * Adds a {@link Vehicle} to the container.
     * <p>
     * Before adding, the method checks if the vehicle's VIN already exists in the container.
     * If the VIN exists, an error message is printed and the vehicle is not added.
     * </p>
     * 
     * @param vehicle The {@link Vehicle} to add.
     */
    public static void addVehicle(Vehicle vehicle) {
        if (vinExists(vehicle.getVIN())) {
            System.err.println("Error: Vehicle with this VIN already exists.");
        } else {
            vehicles.add(vehicle);
            // System.out.println("Vehicle added successfully: " + vehicle);
        }
    }

    /**
     * Retrieves a {@link Vehicle} from the container based on its VIN.
     * 
     * @param VIN The Vehicle Identification Number of the desired vehicle.
     * @return The {@link Vehicle} object if found, or {@code null} if no vehicle with the given VIN exists.
     */
    public static Vehicle getVehicle(int VIN) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getVIN() == VIN) {
                return vehicle;
            }
        }
        System.err.println("Error: No vehicle found with this VIN.");
        return null;
    }

    /**
     * Checks if a vehicle with the specified VIN exists in the container.
     * 
     * @param VIN The Vehicle Identification Number to check.
     * @return {@code true} if a vehicle with the specified VIN exists, {@code false} otherwise.
     */
    public static boolean vinExists(int VIN) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getVIN() == VIN) {
                return true;
            }
        }
        return false;
    }

    /**
     * Removes a {@link Vehicle} from the container based on its VIN.
     * 
     * @param vin The Vehicle Identification Number of the vehicle to remove.
     * @return {@code true} if the vehicle was successfully removed, {@code false} if no vehicle with the given VIN exists.
     */
    public static boolean removeVehicle(int vin) {
        for (int i = 0; i < vehicles.size(); i++) {
            if (vehicles.get(i).getVIN() == vin) { // Use '==' for int comparison
                vehicles.remove(i); // Remove the vehicle
                return true; // Indicate successful removal
            }
        }
        return false; // Return false if the vehicle is not found
    }
}

