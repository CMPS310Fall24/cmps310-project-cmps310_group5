package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Dima
 * @author Aisha
 * 
 * Unit test class for the {@link Owner} class.
 * This class uses JUnit 5 to validate the functionality of the {@link Owner} class,
 * ensuring that its attributes and methods behave as expected.
 * 
 * The tests cover:
 * <ul>
 *   <li>Retrieving the owner's name</li>
 *   <li>Retrieving the owner's QID</li>
 *   <li>Retrieving the owner's address</li>
 *   <li>Retrieving the owner's phone number</li>
 * </ul>
 * 
 */
class OwnerTest {

    // Sample data for testing
    Owner Ownertest = new Owner("Dima Faris", 123, "dima.faris@example.com", 123456789);

    /**
     * Comprehensive test to validate all aspects of an {@link Owner}.
     * Calls individual test methods for each attribute.
     */
    @Test
    void testOwner() {
        testGetName();
        testGetQID();
        testGetAddress();
        testGetPhoneNumber();
    }

    /**
     * Tests the {@link Owner#getName()} method.
     * Ensures the name of the owner is correctly retrieved.
     */
    @Test
    void testGetName() {
        assertEquals("Dima Faris", Ownertest.getName());
    }

    /**
     * Tests the {@link Owner#getQID()} method.
     * Ensures the QID of the owner is correctly retrieved.
     */
    @Test
    void testGetQID() {
        assertEquals(123, Ownertest.getQID());
    }

    /**
     * Tests the {@link Owner#getAddress()} method.
     * Ensures the address of the owner is correctly retrieved.
     */
    @Test
    void testGetAddress() {
        assertEquals("dima.faris@example.com", Ownertest.getAddress());
    }

    /**
     * Tests the {@link Owner#getPhoneNumber()} method.
     * Ensures the phone number of the owner is correctly retrieved.
     */
    @Test
    void testGetPhoneNumber() {
        assertEquals(123456789, Ownertest.getPhoneNumber());
    }
}
