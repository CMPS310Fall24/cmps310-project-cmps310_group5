package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Aisha
 * Unit test class for the {@link Vehicle} class.
 * This class uses JUnit 5 to validate the functionality of the {@link Vehicle} class,
 * focusing on attributes and methods specific to a simplified vehicle scenario.
 * 
 * The tests cover:
 * 
 * Retrieving the vehicle's VIN
 * Checking the current owner
 * Retrieving the previous owner
 * Verifying unpaid bills status
 */
class VehicleTest2 {

    // Sample data for testing
    Owner owner = new Owner(202005566, "Ali Jassim");
    Vehicle vehicle = new Vehicle(123, owner, true);

    /**
     * Tests the {@link Vehicle#getVIN()} method.
     * Ensures the Vehicle Identification Number (VIN) is correctly retrieved.
     */
    @Test
    void testGetVIN() {
        assertEquals(123, vehicle.getVIN());
    }


    /**
     * Tests the {@link Vehicle#getPreviousOwner()} method.
     * Ensures the previous owner of the vehicle is correctly retrieved.
     * Since no previous owner is set, the expected value is {@code null}.
     */
    @Test
    void testGetPreviousOwner() {
        assertEquals(null, vehicle.getPreviousOwner());
    }

    /**
     * Tests the {@link Vehicle#hasUnpaidBills()} method.
     * Ensures the unpaid bills status of the vehicle is correctly retrieved.
     */
    @Test
    void testHasUnpaidBills() {
        assertEquals(true, vehicle.hasUnpaidBills());
    }

    /**
     * Comprehensive test to validate all aspects of a {@link Vehicle}.
     * Calls individual test methods for each attribute and behavior.
     */
    @Test
    void testVehicle() {
        testGetVIN();
        testGetPreviousOwner();
        testHasUnpaidBills();
    }
}
