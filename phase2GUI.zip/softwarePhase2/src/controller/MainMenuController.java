package controller;

import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import transferRegVehicle.TransferVehicleApp;

/**
 * @author Dima
 * @author Aisha
 * 
 * Controller class for the main menu of the application.
 *
 * This controller handles user interactions in the main menu, allowing navigation to the accident management and 
 * vehicle registration transfer modules.
 * 
 * 
 *Key Features:
 *Navigate to the accident management view.
 *Launch the transfer vehicle registration application in a new stage.
 *Display user messages and handle scene switching.
 */
public class MainMenuController {

    @FXML
    private Button ManageAccidentButton; // Button to navigate to accident management

    @FXML
    private Button TransferRegisterButton; // Button to launch transfer vehicle registration

    /**
     * Navigates to the accident management view.
     * <p>
     * This method switches the scene to the Login view where users can manage accidents.
     * </p>
     * 
     * @param event The {@link ActionEvent} triggered by clicking the "Manage Accident" button.
     */
    @FXML
    void manageAccident(ActionEvent event) {
        switchScene("/view/LoginView.fxml");
    }

    /**
     * Launches the transfer vehicle registration application in a new stage.
     * <p>
     * This method initializes and starts the {@link TransferVehicleApp} on a new stage using the JavaFX platform thread.
     * </p>
     * 
     * @param event The {@link ActionEvent} triggered by clicking the "Transfer Register" button.
     */
    @FXML
    void transferRegister(ActionEvent event) {
        launchTransferVehicleApp();
    }

    /**
     * Launches the {@link TransferVehicleApp} in a new stage.
     * <p>
     * This method ensures thread safety by running on the JavaFX application thread. 
     * If the launch fails, an error message is displayed to the user.
     * </p>
     */
    private void launchTransferVehicleApp() {
        Platform.runLater(() -> {
            try {
                TransferVehicleApp transferVehicleApp = new TransferVehicleApp();
                Stage newStage = new Stage(); // Create a new stage for the transfer vehicle app
                transferVehicleApp.start(newStage); // Start the new stage
            } catch (Exception e) {
                e.printStackTrace();
                displayMessage("Failed to launch the Transfer Vehicle app: " + e.getMessage(), AlertType.ERROR);
            }
        });
    }

    /**
     * Displays a message to the user in an alert dialog.
     * 
     * @param message The message to display.
     * @param type    The type of the alert (e.g., {@link AlertType#INFORMATION}, {@link AlertType#ERROR}).
     */
    public void displayMessage(String message, AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle("APS Message");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Switches the scene to the specified FXML file.
     * <p>
     * This method loads the FXML file and updates the current stage with the new scene. 
     * If loading fails, an error message is displayed.
     * </p>
     * 
     * @param fxmlPath The path to the FXML file for the new scene.
     */
    private void switchScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Scene scene = new Scene(loader.load());

            // Get the current stage and set the new scene
            Stage stage = (Stage) ManageAccidentButton.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            displayMessage("Failed to load the scene: " + e.getMessage(), AlertType.ERROR);
        }
    }
}

