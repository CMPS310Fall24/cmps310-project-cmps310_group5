package controller;

import java.io.IOException;
import java.util.function.Consumer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import model.Vehicle;
import model.VehicleContainer;

/**
 * @author Dima
 * Controller class for the login functionality of the application.
 * 
 * This controller handles retrieving vehicle details for both offender and victim vehicles
 * based on their VINs and transitioning to the accident management view upon successful retrieval.
 * 
 *Key Features:
 *Retrieve and validate vehicle details for the offender and victim using VINs.
 *Display appropriate messages for validation errors or success.
 *Switch to the "Manage Accident" view with the retrieved vehicle details.
 */
public class LoginController {

    @FXML
    private TextField vinOffenderField; // Text field to enter the offender's VIN

    @FXML
    private TextField vinVictimField; // Text field to enter the victim's VIN

    @FXML
    private Label offenderDetailsLabel; // Label to display the offender's details

    @FXML
    private Label victimDetailsLabel; // Label to display the victim's details

    @FXML
    private Button retrieveButton; // Button to retrieve vehicle details

    private boolean detailsRetrieved = false; // Flag to track if details have been retrieved successfully

    /**
     * Handles the retrieval of vehicle details for both offender and victim vehicles.
     * <p>
     * This method validates the input VINs, retrieves the corresponding {@link Vehicle} objects
     * from the {@link VehicleContainer}, and switches to the "Manage Accident" view upon success.
     * </p>
     * 
     * @param event The {@link ActionEvent} triggered by the retrieve button.
     */
    @FXML
    void handleRetrieve(ActionEvent event) {
        String vinOffenderInput = vinOffenderField.getText();
        String vinVictimInput = vinVictimField.getText();

        if (vinOffenderInput.isEmpty() || vinVictimInput.isEmpty()) {
            displayMessage("Please enter both VINs to proceed.", AlertType.ERROR);
            return;
        }

        try {
            int vinOffender = Integer.parseInt(vinOffenderInput);
            int vinVictim = Integer.parseInt(vinVictimInput);

            Vehicle offenderVehicle = VehicleContainer.getVehicle(vinOffender);
            Vehicle victimVehicle = VehicleContainer.getVehicle(vinVictim);

            if (offenderVehicle == null) {
                displayMessage("No vehicle found with VIN: " + vinOffender, AlertType.ERROR);
                return;
            }

            if (victimVehicle == null) {
                displayMessage("No vehicle found with VIN: " + vinVictim, AlertType.ERROR);
                return;
            }

            detailsRetrieved = true;
            displayMessage("Vehicle details retrieved successfully.", AlertType.INFORMATION);

            switchScene("/view/ManageAccidentView.fxml", controller -> {
                if (controller instanceof ManageAccidentController) {
                    ManageAccidentController manageAccidentController = (ManageAccidentController) controller;
                    manageAccidentController.setVehicleDetails(offenderVehicle, victimVehicle);
                }
            });
        } catch (NumberFormatException e) {
            displayMessage("VIN must be a numeric value.", AlertType.ERROR);
        }
    }

    /**
     * Displays a message to the user in an alert dialog.
     * 
     * @param message The message to display.
     * @param type    The type of the alert (e.g., {@link AlertType#INFORMATION}, {@link AlertType#ERROR}).
     */
    private void displayMessage(String message, AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle("APS Message");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Switches the scene to the specified FXML file and sets up the corresponding controller.
     *
     * This method loads the new scene, applies the controller setup logic, and updates the stage.
     *
     * 
     * @param fxmlPath       The path to the FXML file for the new scene.
     * @param controllerSetup A {@link Consumer} to configure the new controller with specific logic.
     */
    private void switchScene(String fxmlPath, Consumer<Object> controllerSetup) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Scene scene = new Scene(loader.load());

            Object controller = loader.getController();

            if (controllerSetup != null) {
                controllerSetup.accept(controller);
            }

            Stage stage = (Stage) retrieveButton.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            displayMessage("Failed to load the scene: " + e.getMessage(), AlertType.ERROR);
        }
    }
}
