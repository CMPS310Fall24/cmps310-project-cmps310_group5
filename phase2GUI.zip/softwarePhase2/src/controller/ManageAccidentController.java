package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * @author Dima
 * 
 * Controller class for managing accident reports.
 * 
 * This controller handles the submission of accident reports, including validating inputs, 
 * generating reports, and integrating with insurance companies for approval and acknowledgements.
 * 
 * Key Features:
 *Capture accident details such as date, time, location, and description.
 *Validate inputs for proper date and time formatting.
 *Generate accident reports and submit them to the {@link AccidentContainer}.
 *Interact with {@link InsuranceCompany} for approval and acknowledgement generation.
 *Display confirmation dialogs for user review before submission.
 * 
 */
public class ManageAccidentController {

    @FXML private TextField accidentDateField; // Field for entering the accident date
    @FXML private TextField accidentTimeField; // Field for entering the accident time
    @FXML private TextArea accidentDescriptionField; // Field for entering accident description
    @FXML private TextField accidentLocationField; // Field for entering the accident location
    @FXML private Button submitButton; // Button to submit the accident report
    @FXML private Button cancelButton; // Button to cancel the accident report submission

    private Vehicle offenderVehicle; // Vehicle of the offender involved in the accident
    private Vehicle victimVehicle; // Vehicle of the victim involved in the accident

    /**
     * Handles the submission of an accident report.
     * <p>
     * This method validates input fields, ensures all fields are filled, 
     * and checks for proper date and time formatting. If validation passes, 
     * it creates a new {@link Accident} object and submits it to the {@link AccidentContainer}.
     * If the victim's insurance policy is valid, it generates a report and interacts with the insurance company.
     * 
     * @param event The {@link ActionEvent} triggered by the submit button.
     */
    @FXML
    public void handleSubmitAccidentReport(ActionEvent event) {
        try {
            String date = accidentDateField.getText();
            String time = accidentTimeField.getText();
            String description = accidentDescriptionField.getText();
            String location = accidentLocationField.getText();

            if (date.isEmpty() || time.isEmpty() || description.isEmpty() || location.isEmpty()) {
                displayMessage("All fields must be filled out.", Alert.AlertType.ERROR);
                return;
            }

            LocalDate dateInput;
            try {
                dateInput = LocalDate.parse(date);
            } catch (DateTimeParseException e) {
                displayMessage("Invalid date format. Please use YYYY-MM-DD.", Alert.AlertType.ERROR);
                return;
            }

            LocalTime timeInput;
            try {
                timeInput = LocalTime.parse(time, DateTimeFormatter.ofPattern("HH:mm"));
            } catch (DateTimeParseException e) {
                displayMessage("Invalid time format. Please use HH:mm (24-hour clock).", Alert.AlertType.ERROR);
                return;
            }

            Owner offenderOwner = offenderVehicle.getOwner();
            Owner victimOwner = victimVehicle.getOwner();

            if (offenderOwner == null || victimOwner == null) {
                displayMessage("Both offender and victim vehicles must have assigned owners.", Alert.AlertType.ERROR);
                return;
            }

            boolean confirmed = showConfirmationDialog(dateInput, timeInput, location, offenderOwner, victimOwner);
            if (!confirmed) {
                displayMessage("Accident report submission cancelled by the user.", Alert.AlertType.INFORMATION);
                return;
            }

            Accident accident = new Accident(dateInput, timeInput, location, victimOwner, offenderOwner);
            AccidentContainer.addReport(accident);
            accident.setConfirmation(true);

            if (victimVehicle.getPolicy().isValidity()) {
                accident.generateReport();
                InsuranceCompany company = victimVehicle.getPolicy().getCompany();
                boolean isApproved = company.giveApproval(accident.getReport());
                if (isApproved) {
                    Aknowledgement.generateAknowledgement(accident.getReport(), company, isApproved);
                }
            }

            displayMessage("Accident Report Submitted Successfully.", Alert.AlertType.INFORMATION);

        } catch (Exception e) {
            displayMessage("Error submitting accident report: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Clears all input fields in the form.
     * 
     * This method is triggered when the cancel button is clicked, resetting the form to its default state
     * 
     * @param event The {@link ActionEvent} triggered by the cancel button.
     */
    public void handleCancel(ActionEvent event) {
        accidentDateField.clear();
        accidentTimeField.clear();
        accidentDescriptionField.clear();
        accidentLocationField.clear();
    }

    /**
     * Displays a message to the user in an alert dialog.
     * 
     * @param message The message to display.
     * @param type    The type of the alert (e.g., {@link Alert.AlertType#INFORMATION}, {@link Alert.AlertType#ERROR}).
     */
    public void displayMessage(String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle("APS Message");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Shows a confirmation dialog to the user for accident report review.
     * 
     * @param date          The date of the accident.
     * @param time          The time of the accident.
     * @param location      The location of the accident.
     * @param offenderOwner The owner of the offender vehicle.
     * @param victimOwner   The owner of the victim vehicle.
     * @return {@code true} if the user confirms the details, {@code false} otherwise.
     */
    private boolean showConfirmationDialog(LocalDate date, LocalTime time, String location, Owner offenderOwner, Owner victimOwner) {
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Confirm Accident Report");
        confirmationAlert.setHeaderText("Please confirm the accident details before submission:");
        confirmationAlert.setContentText(
            "Date: " + date +
            "\nTime: " + time +
            "\nLocation: " + location +
            "\nOffender Owner: " + offenderOwner.getName() +
            "\nVictim Owner: " + victimOwner.getName()
        );

        return confirmationAlert.showAndWait().filter(response -> response == ButtonType.OK).isPresent();
    }

    /**
     * Sets the offender and victim vehicles involved in the accident.
     * 
     * @param offender The offender {@link Vehicle}.
     * @param victim   The victim {@link Vehicle}.
     */
    public void setVehicleDetails(Vehicle offender, Vehicle victim) {
        this.offenderVehicle = offender;
        this.victimVehicle = victim;

        //System.out.println("Offender Vehicle: " + offenderVehicle);
        //System.out.println("Victim Vehicle: " + victimVehicle);
    }
}

