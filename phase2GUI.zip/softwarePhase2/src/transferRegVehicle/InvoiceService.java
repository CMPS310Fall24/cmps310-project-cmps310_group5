package transferRegVehicle;

import model.Vehicle;

/**
 * 
 * @author Aisha
 * 
 * A class for handling invoice generation related to vehicle transfers.
 * 
 * This class provides a method to generate an invoice when a vehicle's ownership
 * is transferred to a new owner.
 */
class InvoiceService {
	/**
     * Generates an invoice for the transfer of a vehicle's ownership.
     *
     * This method takes a Vehicle object and outputs a message
     * confirming that the invoice has been created for the specified vehicle.
     *
     * @param vehicle the vehicle for which the invoice is created
     *                (must not be null)
     */
    public static void createInvoice(Vehicle vehicle) {
        System.out.println("Invoice created for the transfer of vehicle with VIN: " + vehicle.getVIN());
    }
}
