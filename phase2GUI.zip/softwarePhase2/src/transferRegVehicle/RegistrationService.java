package transferRegVehicle;

import model.Owner;
import model.Vehicle;

/**
 * @author Aisha
 * 
 * A service class responsible for vehicle registration operations.
 * <p>
 * This class provides methods for verifying vehicle registration details and transferring ownership
 * of a registered vehicle. It interacts with the {@link VehicleContainer} to retrieve and update vehicle
 * data, and it leverages external services like {@link StickerService} and {@link InvoiceService} to
 * generate stickers and invoices for registration processes.
 * </p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li>Verify vehicle registration details against the provided owner information.</li>
 *   <li>Transfer ownership of a vehicle and handle associated updates, like generating stickers and invoices.</li>
 * </ul>

 */
public class RegistrationService {

    /**
     * Verifies the registration details of a vehicle.
     * <p>
     * This method checks if a vehicle with the specified VIN exists in the system. It validates the provided
     * owner details, including name and QID, and ensures there are no unpaid bills associated with the vehicle.
     * </p>
     * 
     * @param vin The Vehicle Identification Number of the vehicle.
     * @param owner The {@link Owner} object containing the owner's details to verify.
     * @return A status message indicating the result of the verification:
     *         <ul>
     *           <li>"Vehicle not found." if no vehicle exists with the given VIN.</li>
     *           <li>"Incorrect Information." if the owner details do not match.</li>
     *           <li>"Pay the bills first." if there are unpaid bills for the vehicle.</li>
     *           <li>"Success" if the registration details are verified successfully.</li>
     *         </ul>
     */
    public String verifyRegistration(int vin, Owner owner) {
        Vehicle vehicle = VehicleContainer.getVehicleByVin(vin);
        if (vehicle == null) {
            return "Vehicle not found.";
        }

        if (!vehicle.getOwner().getName().equals(owner.getName()) || 
                vehicle.getOwner().getQID() != owner.getQID()) {
            return "Incorrect Information.";
        }

        if (vehicle.hasUnpaidBills()) {
            return "Pay the bills first.";
        }

        return "Success";
    }

    /**
     * Transfers the ownership of a vehicle to a new owner.
     * <p>
     * This method checks if the vehicle with the specified VIN exists in the system. If it exists, it updates
     * the ownership by setting the current owner as the previous owner and assigning the new owner as the current owner.
     * It then updates the vehicle details in the system and triggers the generation of a registration sticker and invoice.
     * </p>
     * 
     * @param vin The Vehicle Identification Number of the vehicle.
     * @param newOwner The {@link Owner} object containing the new owner's details.
     * @return A status message indicating the result of the ownership transfer:
     *         <ul>
     *           <li>"Vehicle not found." if no vehicle exists with the given VIN.</li>
     *           <li>"Ownership transferred successfully!" if the ownership transfer is successful.</li>
     *         </ul>
     */
    public String transferOwnership(int vin, Owner newOwner) {
        Vehicle vehicle = VehicleContainer.getVehicleByVin(vin);
        if (vehicle == null) {
            return "Vehicle not found.";
        }

        // Set the current owner as the previous owner
        vehicle.setPreviousOwner(vehicle.getOwner());

        // Assign the new owner as the current owner
        vehicle.setOwner(newOwner);

        // Update the database with the modified vehicle
        VehicleContainer.updateVehicle(vin, vehicle);

        // Generate registration sticker
        StickerService.generateSticker(vehicle);

        // Create an invoice
        InvoiceService.createInvoice(vehicle);

        return "Ownership transferred successfully!";
    }
}
