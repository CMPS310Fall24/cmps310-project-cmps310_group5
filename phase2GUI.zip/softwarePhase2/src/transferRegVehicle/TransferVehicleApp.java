package transferRegVehicle;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.Owner;
import model.Vehicle;

/**
 * @author Aisha
 * A JavaFX application for transferring registered vehicle ownership.
 *
 * This application allows users to fetch and verify vehicle registration details,
 * then transfer ownership of a registered vehicle to a new owner.
 * 
 * Key Features:
 * Fetch registration details by VIN and validate owner information.
 * Transfer ownership to a new owner after validation.
 * Update UI components to reflect the registration and ownership transfer status.
 * 
 */
public class TransferVehicleApp extends Application {

    private RegistrationService registrationService = new RegistrationService();

    /**
     * Initializes the JavaFX application and sets up the UI for transferring vehicle ownership.
     * 
     * @param primaryStage The primary stage for the application.
     */
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Transfer Registered Vehicle");

        // GUI Components
        Label vinLabel = new Label("Vehicle VIN:");
        TextField vinField = new TextField();

        Label ownerNameLabel = new Label("Owner Name:");
        TextField ownerNameField = new TextField();

        Label ownerQIDLabel = new Label("Owner QID:");
        TextField ownerQIDField = new TextField();

        Button fetchDetailsButton = new Button("Fetch Registration Details");
        Label fetchMessageLabel = new Label();

        Label newOwnerNameLabel = new Label("New Owner Name:");
        TextField newOwnerNameField = new TextField();
        newOwnerNameField.setDisable(true);

        Label newOwnerQIDLabel = new Label("New Owner QID:");
        TextField newOwnerQIDField = new TextField();
        newOwnerQIDField.setDisable(true);

        Button transferButton = new Button("Transfer Ownership");
        transferButton.setDisable(true);

        Label resultMessageLabel = new Label();

        // Labels for current and previous owners
        Label currentOwnerLabel = new Label("Current Owner:");
        Label currentOwnerValueLabel = new Label();

        Label previousOwnerLabel = new Label("Previous Owner:");
        Label previousOwnerValueLabel = new Label();

        // Layout
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setVgap(10);
        gridPane.setHgap(10);

        // Add components to the grid layout
        gridPane.add(vinLabel, 0, 0);
        gridPane.add(vinField, 1, 0);
        gridPane.add(ownerNameLabel, 0, 1);
        gridPane.add(ownerNameField, 1, 1);
        gridPane.add(ownerQIDLabel, 0, 2);
        gridPane.add(ownerQIDField, 1, 2);
        gridPane.add(fetchDetailsButton, 1, 3);
        gridPane.add(fetchMessageLabel, 1, 4);
        gridPane.add(newOwnerNameLabel, 0, 5);
        gridPane.add(newOwnerNameField, 1, 5);
        gridPane.add(newOwnerQIDLabel, 0, 6);
        gridPane.add(newOwnerQIDField, 1, 6);
        gridPane.add(transferButton, 1, 7);
        gridPane.add(resultMessageLabel, 1, 8);
        gridPane.add(currentOwnerLabel, 0, 9);
        gridPane.add(currentOwnerValueLabel, 1, 9);
        gridPane.add(previousOwnerLabel, 0, 10);
        gridPane.add(previousOwnerValueLabel, 1, 10);

        // Fetch Details Button Action
        fetchDetailsButton.setOnAction(event -> {
            String vinText = vinField.getText();
            String ownerName = ownerNameField.getText();
            String ownerQIDText = ownerQIDField.getText();

            if (vinText.isEmpty() || ownerName.isEmpty() || ownerQIDText.isEmpty()) {
                fetchMessageLabel.setText("All fields are required!");
                return;
            }

            try {
                int vin = Integer.parseInt(vinText); // Convert VIN to int
                int ownerQID = Integer.parseInt(ownerQIDText);
                Owner owner = new Owner(ownerQID, ownerName);
                String fetchResult = registrationService.verifyRegistration(vin, owner);

                if (fetchResult.equals("Success")) {
                    fetchMessageLabel.setText("Registration details verified successfully.");
                    newOwnerNameField.setDisable(false);
                    newOwnerQIDField.setDisable(false);
                    transferButton.setDisable(false);

                    // Get current owner details and update the label
                    Vehicle vehicle = VehicleContainer.getVehicleByVin(vin);
                    if (vehicle != null) {
                        currentOwnerValueLabel.setText(vehicle.getOwner().getName());
                    }
                } else {
                    fetchMessageLabel.setText(fetchResult);
                    newOwnerNameField.setDisable(true);
                    newOwnerQIDField.setDisable(true);
                    transferButton.setDisable(true);
                    currentOwnerValueLabel.setText(""); // Clear current owner if verification fails
                }
            } catch (NumberFormatException e) {
                fetchMessageLabel.setText("VIN and QID must be valid numbers.");
            }
        });

        // Transfer Ownership Button Action
        transferButton.setOnAction(event -> {
            String vinText = vinField.getText();
            String newOwnerName = newOwnerNameField.getText();
            String newOwnerQIDText = newOwnerQIDField.getText();

            if (newOwnerName.isEmpty() || newOwnerQIDText.isEmpty()) {
                resultMessageLabel.setText("New owner details are required!");
                return;
            }

            try {
                int vin = Integer.parseInt(vinText); // Convert VIN to int
                int newOwnerQID = Integer.parseInt(newOwnerQIDText);
                Owner newOwner = new Owner(newOwnerQID, newOwnerName);
                String transferResult = registrationService.transferOwnership(vin, newOwner);

                resultMessageLabel.setText(transferResult);

                // Update owner labels after successful transfer
                if (transferResult.equals("Ownership transferred successfully!")) {
                    Vehicle vehicle = VehicleContainer.getVehicleByVin(vin);
                    if (vehicle != null) {
                        currentOwnerValueLabel.setText(vehicle.getOwner().getName());
                        previousOwnerValueLabel.setText(vehicle.getPreviousOwner().getName());
                    }
                }
            } catch (NumberFormatException e) {
                resultMessageLabel.setText("VIN and QID must be valid numbers.");
            }
        });

        // Scene and Stage
        Scene scene = new Scene(gridPane, 400, 450);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * The main entry point for the JavaFX application.
     * 
     * @param args Command-line arguments.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
