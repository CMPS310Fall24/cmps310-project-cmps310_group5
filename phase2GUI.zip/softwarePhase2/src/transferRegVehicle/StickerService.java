package transferRegVehicle;

import model.Vehicle;

/**
 * @author Aisha
 * A utility class for generating registration stickers for vehicles.
 * 
 * This class provides a static method to generate a new registration sticker for a given {@link Vehicle}.
 * It is typically used as part of the vehicle registration and ownership transfer process.
 * 
 */
class StickerService {

    /**
     * Generates a new registration sticker for the specified {@link Vehicle}.
     * 
     * This method simulates the creation of a registration sticker by printing a message to the console
     * indicating that a sticker has been generated for the vehicle's VIN.
     * 
     * 
     * @param vehicle The {@link Vehicle} object for which the sticker is generated.
     *                The method retrieves the VIN from the vehicle and includes it in the output.
     */
    public static void generateSticker(Vehicle vehicle) {
        System.out.println("New registration sticker generated for VIN: " + vehicle.getVIN());
    }
}
