package transferRegVehicle;

import java.util.ArrayList;
import java.util.List;

import model.Owner;
import model.Vehicle;

/**
 * @author Aisha
 * 
 * A container class for managing a collection of {@link Vehicle} objects.
 * 
 * This class provides static methods for retrieving, updating, adding, and removing vehicles based on their VIN (Vehicle Identification Number).
 * It serves as a central repository for vehicles in the system.
 * 
 *Key Features:
 *Retrieve a vehicle by its VIN
 *Update or add a vehicle to the repository
 *Remove a vehicle from the repository by VIN
 * 
 */
public class VehicleContainer {

    private static List<Vehicle> vehicles = new ArrayList<>(); // List to store vehicle objects

    static {
        // Pre-populated vehicles for demonstration
        vehicles.add(new Vehicle(123, new Owner(202005566, "Ali Jassim"), true)); // Has unpaid bills
        vehicles.add(new Vehicle(333, new Owner(202004377, "Aisha Ali"), false));
    }

    /**
     * Retrieves a {@link Vehicle} from the repository based on its VIN.
     * 
     * @param vin The Vehicle Identification Number of the desired vehicle.
     * @return The {@link Vehicle} object if found, or {@code null} if no vehicle with the given VIN exists.
     */
    public static Vehicle getVehicleByVin(int vin) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getVIN() == vin) { // Use '==' for int comparison
                return vehicle;
            }
        }
        return null; // Return null if no vehicle is found with the given VIN
    }

    /**
     * Updates an existing {@link Vehicle} in the repository or adds a new one if it does not exist.
     * <p>
     * If a vehicle with the specified VIN is found, it is replaced with the provided {@code updatedVehicle}.
     * If no vehicle with the VIN exists, the {@code updatedVehicle} is added to the repository.
     * </p>
     * 
     * @param vin The Vehicle Identification Number of the vehicle to update or add.
     * @param updatedVehicle The updated {@link Vehicle} object.
     */
    public static void updateVehicle(int vin, Vehicle updatedVehicle) {
        for (int i = 0; i < vehicles.size(); i++) {
            if (vehicles.get(i).getVIN() == vin) { // Use '==' for int comparison
                vehicles.set(i, updatedVehicle); // Replace the vehicle if VIN matches
                return;
            }
        }
        vehicles.add(updatedVehicle); // Add the vehicle if not found
    }

    /**
     * Removes a {@link Vehicle} from the repository based on its VIN.
     * 
     * @param vin The Vehicle Identification Number of the vehicle to remove.
     * @return {@code true} if the vehicle was successfully removed, {@code false} if no vehicle with the given VIN exists.
     */
    public static boolean removeVehicle(int vin) {
        for (int i = 0; i < vehicles.size(); i++) {
            if (vehicles.get(i).getVIN() == vin) { // Use '==' for int comparison
                vehicles.remove(i); // Remove the vehicle
                return true; // Indicate successful removal
            }
        }
        return false; // Return false if the vehicle is not found
    }
}

